<?php $__env->startSection('title', 'Tabler'); ?>
<?php $__env->startSection('content'); ?>
aa
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tabler::layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/home.blade.php ENDPATH**/ ?>