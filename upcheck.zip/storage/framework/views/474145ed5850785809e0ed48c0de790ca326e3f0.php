<ul class="nav nav-tabs border-0 flex-column flex-lg-row">
    <?php $__currentLoopData = Menu::get('primary')->roots(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li <?php $lm_attrs = $item->attr(); ob_start(); ?> class="nav-item" <?php echo \Lavary\Menu\Builder::mergeStatic(ob_get_clean(), $lm_attrs); ?>>
            <a class="nav-link" <?php if($item->hasChildren()): ?> href="javascript:void(0)" data-toggle="dropdown"
               <?php else: ?> href="<?php echo $item->url(); ?>" <?php endif; ?>><?php echo $item->title; ?> </a>
            <?php if($item->hasChildren()): ?>
                <div class="dropdown-menu dropdown-menu-arrow">
                    <?php $__currentLoopData = $item->children(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo $childItem->url(); ?>" class="dropdown-item "><?php echo $childItem->title; ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/tabler/_partials/primary-menu.blade.php ENDPATH**/ ?>