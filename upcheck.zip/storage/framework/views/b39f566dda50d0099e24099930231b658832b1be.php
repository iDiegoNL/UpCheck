<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(isset($title) ? $title . ' | ' . config('tabler.suffix') : config('tabler.suffix')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">
    <link href="<?php echo e(asset('admin/assets/css/dashboard.css')); ?>" rel="stylesheet"/>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/hint.css/2.6.0/hint.min.css" integrity="sha256-UMhOZKeAbUSd/AoZKm+rlqzsBhzI7dTOYf2Euns4Es8=" crossorigin="anonymous" />
    <script src="<?php echo e(asset('admin/assets/js/require.min.js')); ?>"></script>
    <script>
        requirejs.config({
            baseUrl: './admin'
        });
    </script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
    <?php echo $__env->make('googletagmanager::head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<body>
<?php echo $__env->make('googletagmanager::body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page">
    <div class="page-main">
        <div class="header py-4">
            <div class="container">
                <div class="d-flex">
                    <a class="header-brand" href="<?php echo url(config('tabler.urls.homepage', '/')); ?>">
                        <img src="<?php echo config('tabler.logo'); ?>" class="header-brand-img" alt="Logo">
                    </a>
                    <div class="d-flex order-lg-2 ml-auto">
                        <?php if(Auth::check()): ?>
                            <?php echo $__env->make('tabler::_partials.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                    <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse"
                       data-target="#headerMenuCollapse">
                        <span class="header-toggler-icon"></span>
                    </a>
                </div>
            </div>
        </div>
        <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
            <div class="container">
                <div class="row align-items-center">
                    <?php if(config('tabler.support.search')): ?>
                        <div class="col-lg-3 ml-auto">
                            <form class="input-icon my-3 my-lg-0" action="<?php echo config('tabler.urls.searchUrl'); ?>"
                                  method="GET">
                                <input type="search" class="form-control header-search" placeholder="Search&hellip;"
                                       tabindex="1" name="keywords">
                                <div class="input-icon-addon">
                                    <i class="fe fe-search"></i>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                    <div class="col-lg order-lg-first">
                        <?php if(Menu::exists('primary')): ?>
                            <?php echo $__env->make('tabler::_partials.primary-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-3 my-md-5">
            <div class="container">
                <div class="page-header">
                    <h1 class="page-title">
                        <?php echo e(isset($title) ? $title : ''); ?>

                    </h1>
                </div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <?php if(config('tabler.support.footer-menu')): ?>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <?php if(Menu::exists('footer')): ?>
                                <?php echo $__env->make('tabler::_partials.footer-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <footer class="footer">
        <div class="container">
            <div class="row align-items-center flex-row-reverse">
                <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
                    <?php echo config('tabler.footer'); ?>

                </div>
            </div>
        </div>
    </footer>
</div>
</body>
</html>
<?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/tabler/layouts/main.blade.php ENDPATH**/ ?>