<?php $__env->startSection('title', 'Tabler'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row row-cards row-deck">
        <div class="col-12">
            <div class="card">
                <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                    <thead>
                    <tr>
                        <th class="w-1"></th>
                        <th>Monitor</th>
                        <th>Uptime <a class="hint--top" href="#" aria-label="How is this calculated?"><i class="fal fa-question-circle"></i></a></th>
                        <th class="text-center">Last Ping</th>
                        <th>Activity</th>
                        <th class="text-center">Average Ping</th>
                        <th class="text-center"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $monitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center">
                                <div class="avatar" style="background: transparent;">
                                    <i class="far fa-server"></i>
                                    <?php if($monitor->status == 'online'): ?>
                                        <span class="avatar-status bg-green"></span>
                                    <?php elseif($monitor->status == 'offline'): ?>
                                        <span class="avatar-status bg-red"></span>
                                    <?php else: ?>
                                        <span class="avatar-status bg-gray"></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div><?php echo e($monitor->name); ?> <span class="badge badge-primary"><?php echo e($monitor->id); ?></span></div>
                                <div class="small text-muted">
                                    <?php echo e($monitor->domain . $monitor->ip); ?>

                                </div>
                            </td>
                            <td>
                                <div class="clearfix">
                                    <div class="float-left">
                                        <strong>42%</strong>
                                    </div>
                                    <div class="float-right">
                                        <small class="text-muted">Jun 11, 2015 - Jul 10, 2015</small>
                                    </div>
                                </div>
                                <div class="progress progress-xs">
                                    <div class="progress-bar bg-yellow" role="progressbar" style="width: 42%"
                                         aria-valuenow="42" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </td>
                            <td class="text-center">
                                <?php echo e(\App\Ping::where('monitor_id', $monitor->id)->orderBy("created_at", "desc")->first()->value('ms')); ?> <span class="text-muted">ms</span>
                            </td>
                            <td>
                                <div class="small text-muted">Last ping</div>
                                <div class="hint--top" aria-label="<?php echo e(\App\Ping::where('monitor_id', $monitor->id)->orderBy("created_at", "desc")->first()->value('created_at')); ?>">
                                    <?php echo e(\Carbon\Carbon::parse(\App\Ping::where('monitor_id', $monitor->id)->orderBy("created_at", "desc")->first()->value('created_at'))->diffForHumans()); ?>

                                </div>
                            </td>
                            <td class="text-center">
                               <div><?php echo e(\App\Ping::where('monitor_id', $monitor->id)->count()); ?> <span class="text-muted">ms</span></div>
                            </td>
                            <td class="text-center">
                                <div class="item-action dropdown">
                                    <a href="javascript:void(0)" data-toggle="dropdown" class="icon"><i
                                                class="fe fe-more-vertical"></i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a href="javascript:void(0)" class="dropdown-item"><i
                                                    class="dropdown-icon fe fe-tag"></i> Action </a>
                                        <a href="javascript:void(0)" class="dropdown-item"><i
                                                    class="dropdown-icon fe fe-edit-2"></i> Another action </a>
                                        <a href="javascript:void(0)" class="dropdown-item"><i
                                                    class="dropdown-icon fe fe-message-square"></i> Something else
                                            here</a>
                                        <div class="dropdown-divider"></div>
                                        <a href="javascript:void(0)" class="dropdown-item"><i
                                                    class="dropdown-icon fe fe-link"></i> Separated link</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="text-center">
                    <div class="card-footer text-muted">
                        <p>
                            Showing <?php echo e($monitors->firstItem()); ?> to <?php echo e($monitors->lastItem()); ?>

                            of <?php echo e(number_format($monitors->total())); ?> monitors
                        </p>
                        <?php echo e($monitors->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tabler::layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/monitors/index.blade.php ENDPATH**/ ?>