<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['url' => url(config('tabler.url.post-register', 'register')), 'method' => 'POST', 'class' => 'card']); ?>

    <div class="card-body p-6">
        <div class="card-title"><?php echo app('translator')->getFromJson('tabler::register.title'); ?></div>
        <div class="form-group">
            <?php echo Form::label('name', trans('tabler::register.name'), ['class' => 'form-label']); ?>

            <?php echo Form::text('name', old('name'), ['placeholder' => trans('tabler::register.name-placeholder'), 'class' => 'form-control', 'autofocus' => true]); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('email', trans('tabler::register.email'), ['class' => 'form-label']); ?>

            <?php echo Form::email('email', old('email'), ['placeholder' => trans('tabler::register.email-placeholder'), 'class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('password', trans('tabler::register.password'), ['class' => 'form-label']); ?>

            <?php echo Form::password('password', ['placeholder' => trans('tabler::register.password-placeholder'), 'class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('password_confirmation', trans('tabler::register.password-confirmation'), ['class' => 'form-label']); ?>

            <?php echo Form::password('password_confirmation', ['placeholder' => trans('tabler::register.password-confirmation-placeholder'), 'class' => 'form-control']); ?>

        </div>
        <div class="form-footer">
            <button type="submit" class="btn btn-primary btn-block"><?php echo app('translator')->getFromJson('tabler::register.singup'); ?></button>
        </div>
    </div>
    <?php echo Form::close(); ?>

    <div class="text-center text-muted">
        <?php echo app('translator')->getFromJson('tabler::register.have-account'); ?> <a href="<?php echo url(config('tabler.url.login-url', 'login')); ?>"><?php echo app('translator')->getFromJson('tabler::register.login'); ?></a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tabler::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/tabler/auth/register.blade.php ENDPATH**/ ?>