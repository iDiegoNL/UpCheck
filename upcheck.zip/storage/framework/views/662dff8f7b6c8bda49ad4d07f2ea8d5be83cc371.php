<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['url' => url(config('tabler.url.post-login', 'login')), 'method' => 'POST', 'class' => 'card']); ?>

    <div class="card-body p-6">
        <div class="card-title"><?php echo app('translator')->getFromJson('tabler::login.title'); ?></div>
        <div class="form-group">
            <?php echo Form::label('email', trans('tabler::login.email'), ['class' => 'form-label']); ?>

            <?php echo Form::email('email', old('email'), ['placeholder' => trans('tabler::login.email-placeholder'), 'class' => 'form-control', 'autofocus' => true]); ?>

        </div>
        <div class="form-group">
            <label class="form-label" for="password">
                <?php echo app('translator')->getFromJson('tabler::login.password'); ?>
                <a href="<?php echo url(config('tabler.urls.forgot', 'password/reset')); ?>" class="float-right small"><?php echo app('translator')->getFromJson('tabler::login.forgot'); ?></a>
            </label>
            <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => trans('tabler::login.password-placeholder')]); ?>

        </div>
        <div class="form-group">
            <label class="custom-control custom-checkbox">
                <?php echo Form::checkbox('remember', null, false, ['class' => 'custom-control-input']); ?>

                <span class="custom-control-label"><?php echo app('translator')->getFromJson('tabler::login.remeber-me'); ?></span>
            </label>
        </div>
        <div class="form-footer">
            <button type="submit" class="btn btn-primary btn-block"><?php echo app('translator')->getFromJson('tabler::login.signin'); ?></button>
        </div>
    </div>
    <?php echo Form::close(); ?>

    <div class="text-center text-muted">
        <?php echo app('translator')->getFromJson('tabler::login.no-account'); ?> <a href="<?php echo url(config('tabler.url.register', 'register')); ?>"><?php echo app('translator')->getFromJson('tabler::login.register'); ?></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tabler::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/tabler/auth/login.blade.php ENDPATH**/ ?>