<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(isset($title) ? $title . ' | ' . config('tabler.suffix') : config('tabler.suffix')); ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">
    <link href="<?php echo e(asset('admin/assets/css/dashboard.css')); ?>" rel="stylesheet"/>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <script src="<?php echo e(asset('admin/assets/js/require.min.js')); ?>"></script>
    <script>
        requirejs.config({
            baseUrl: './admin'
        });
    </script>
    <script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<body>
<div class="page">
    <div class="page-single">
        <div class="container">
            <div class="row">
                <div class="col col-login mx-auto">
                    <div class="text-center mb-6">
                        <img src="<?php echo config('tabler.logo'); ?>" class="h-6" alt="Logo">
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/tabler/layouts/auth.blade.php ENDPATH**/ ?>