<div class="dropdown">
    <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
        <span class="avatar" style="background-image: url('<?php echo e($user->getUrlfriendlyAvatar()); ?>')"></span>
        <span class="ml-2 d-none d-lg-block">
            <span class="text-default"><?php echo e(Auth::user()->name); ?></span>
            <small class="text-muted d-block mt-1"><?php echo e(Auth::user()->email); ?></small>
        </span>
    </a>
    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
        <a class="dropdown-item" href="<?php echo url(config('tabler.urls.profile')); ?>">
            <i class="dropdown-icon fe fe-user"></i> <?php echo app('translator')->getFromJson('tabler::user.profile'); ?>
        </a>
        <a class="dropdown-item" href="<?php echo url(config('tabler.urls.settings')); ?>">
            <i class="dropdown-icon fe fe-settings"></i> <?php echo app('translator')->getFromJson('tabler::user.settings'); ?>
        </a>
        <a class="dropdown-item" href="<?php echo url(config('tabler.urls.logout')); ?>">
            <i class="dropdown-icon fe fe-log-out"></i> <?php echo app('translator')->getFromJson('tabler::user.logout'); ?>
        </a>
    </div>
</div>
<?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/tabler/_partials/user.blade.php ENDPATH**/ ?>