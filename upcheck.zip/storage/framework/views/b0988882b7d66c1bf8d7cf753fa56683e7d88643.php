<?php if($enabled): ?>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e($id); ?>"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php endif; ?>
<?php /**PATH /media/diego/Second Drive/Dev/UpCheck2/resources/views/vendor/googletagmanager/body.blade.php ENDPATH**/ ?>