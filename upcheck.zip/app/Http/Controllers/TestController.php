<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ping;
use App\Monitor;
use App\Jobs\CheckPingTimes;
use Carbon\Carbon;

class TestController extends Controller
{
    public function test()
    {
        $monitors = Monitor::all();

        foreach ($monitors as $monitor) {
            $lastPing = Ping::where('monitor_id', $monitor->id)->orderBy("created_at", "desc")->first();

            echo "$lastPing->created_at<br>";
        }

        echo "<b>" . Carbon::now() . "</b>";
    }
}
